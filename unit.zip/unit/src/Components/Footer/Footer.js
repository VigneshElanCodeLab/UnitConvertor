import React from 'react';
import classes from './Footer.module.css';
function Footer(){
 return(
<div className={classes.footer}>
    Developed by Vignesh Elangovan
</div>
 );
}
export default Footer;